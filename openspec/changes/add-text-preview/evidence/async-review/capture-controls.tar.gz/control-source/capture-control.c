#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int
main(int argc, char **argv)
{
	char *p = malloc(8);
	volatile char value;
	(void)argv;
	if (!p)
		return 2;
	free(p);
	value = p[0];
	fputs("CAPTURE_CONTROL_AFTER_ASAN\n", stderr);
	fflush(stderr);
	if (argc > 1)
		pause();
	return value == 127;
}
