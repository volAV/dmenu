#!/usr/bin/env python3
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

work = Path('/tmp/dmenu-review-corrections-fjivyc9f')
spec = importlib.util.spec_from_file_location('checkpoint', '/home/avo/Projects/private/dmenu/tests/preview-checkpoint.py')
harness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harness)
harness.DIAGNOSTICS_DIR = work / 'capture-controls'
env = {**os.environ, 'DISPLAY': ':93', 'ASAN_OPTIONS': 'halt_on_error=0:detect_leaks=1'}
for forced in (False, True):
    before = len(harness.DIAGNOSTIC_ERRORS)
    menu = harness.Menu(str(work / 'capture-control'), ['hold'] if forced else [], b'', env)
    try:
        deadline = time.monotonic() + 5
        while 'CAPTURE_CONTROL_AFTER_ASAN' not in menu.stderr_text() and time.monotonic() < deadline:
            time.sleep(.005)
        assert 'CAPTURE_CONTROL_AFTER_ASAN' in menu.stderr_text(), 'real ASan diagnostic did not finish emitting'
        if not forced:
            menu.process.wait(timeout=2)
            try:
                menu.wait_window()
            except harness.CheckFailure:
                pass
            else:
                raise AssertionError('unexpected process termination was not detected')
    finally:
        menu.close()
    assert len(harness.DIAGNOSTIC_ERRORS) == before + 1, 'sanitizer finding escaped diagnostic collection'
    records = [json.loads(row) for row in (harness.DIAGNOSTICS_DIR / 'processes.jsonl').read_text().splitlines()]
    record = records[-1]
    text = (harness.DIAGNOSTICS_DIR / record['stderr']).read_text()
    assert record['forced_cleanup'] == forced
    assert 'heap-use-after-free' in text and 'SUMMARY: AddressSanitizer:' in text
    try:
        harness.check_diagnostics()
    except harness.CheckFailure:
        pass
    else:
        raise AssertionError('sanitizer diagnostics did not fail the test')
    print(json.dumps({'control': 'intentional test-only UAF', 'forced_cleanup': forced,
                      'captured_pid': record['pid'], 'status': record['status'],
                      'full_ASan_summary_preserved': True, 'detector_rejected': True}))
