#!/usr/bin/env python3
import json,os,pathlib,shutil,subprocess,time
G=pathlib.Path('/tmp/dmenu-fuzzy-integration-mclmbvjk/gui'); R=G.parent; T=R/'trial'; B='787050237a1b357e53efbec9ef5cc7870a51d041'; F='32fafa2ce7daf1a683e3039bbaf7a9007823e986'; files='Makefile config.mk config.h config.def.h dmenu.c drw.c drw.h util.c util.h arg.h stest.c'.split(); rec=[]
def run(n,c,e,cwd=None,to=420):
 t=time.time()
 try:p=subprocess.run(c,cwd=cwd,env=e,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=to)
 except subprocess.TimeoutExpired as x:p=subprocess.CompletedProcess(c,124,x.stdout or b'',(x.stderr or b'')+b'\nWATCHDOG TIMEOUT\n')
 d=G/'logs';d.mkdir(exist_ok=True);(d/(n+'.stdout')).write_bytes(p.stdout);(d/(n+'.stderr')).write_bytes(p.stderr); rec.append(dict(name=n,command=c,env={k:e[k] for k in ('DISPLAY','ASAN_OPTIONS','UBSAN_OPTIONS') if k in e},cwd=str(cwd) if cwd else None,status=p.returncode,duration=round(time.time()-t,2)));return p
for label,commit in [('original-baseline',B),('corrected-baseline',F)]:
 d=G/'sources'/label;d.mkdir(parents=True,exist_ok=True)
 for f in files:shutil.copy2(T/f,d/f)
 (d/'dmenu.c').write_bytes(subprocess.run(['git','show',commit+':dmenu.c'],cwd=pathlib.Path.cwd(),stdout=subprocess.PIPE,check=True).stdout)
d=G/'sources/current';d.mkdir(parents=True,exist_ok=True)
for f in files:shutil.copy2(T/f,d/f)
variants=[('normal',''),('asan-ubsan','-fsanitize=address,undefined'),('ubsan','-fsanitize=undefined')]
for src in ('original-baseline','corrected-baseline','current'):
 for v,fs in variants:
  if src=='original-baseline' and v!='normal':continue
  if src=='corrected-baseline' and v=='normal':continue
  dest=G/'builds'/f'{src}-{v}';shutil.copytree(G/'sources'/src,dest,dirs_exist_ok=True)
  run('clean-'+src+'-'+v,['make','clean'],os.environ.copy(),dest)
  cflags=f'-std=c99 -pedantic -g -O1 -fno-omit-frame-pointer -Wall -Wextra {fs} -I/usr/include/freetype2 -D_DEFAULT_SOURCE -D_BSD_SOURCE -D_XOPEN_SOURCE=700 -D_POSIX_C_SOURCE=200809L -DVERSION=\\"5.4\\" -DXINERAMA'
  libs=f'{fs} -lX11 -lXinerama -lfontconfig -lXft -lm'
  run('compile-'+src+'-'+v,['make','CC=gcc','CFLAGS='+cflags,'LDFLAGS='+libs],os.environ.copy(),dest)
x=pathlib.Path('/tmp/dmenu-preview-checkpoint-RBbWFs/xvfb/usr/bin/Xvfb');r,w=os.pipe();p=subprocess.Popen([str(x),'-displayfd',str(w),'-screen','0','1280x900x24','-nolisten','tcp'],pass_fds=(w,),stdout=subprocess.DEVNULL,stderr=subprocess.PIPE);os.close(w)
try:
 display=os.read(r,64).decode().strip();os.close(r);e=os.environ.copy();e.update(DISPLAY=':'+display,LC_ALL='C.UTF-8')
 specs=[('normal-full','original-baseline-normal','current-normal',['--baseline',str(G/'builds/original-baseline-normal/dmenu')],{}),('normal-helpers-fuzzy',None,'current-normal',['--helpers-only'],{}),('normal-helpers-token',None,'current-normal',['--helpers-only','--token-mode'],{})]
 for v in ('asan-ubsan','ubsan'):
  specs += [(v+'-full','corrected-baseline-'+v,'current-'+v,['--baseline',str(G/'builds'/('corrected-baseline-'+v)/'dmenu')],{'ASAN_OPTIONS':'detect_leaks=0'} if v=='asan-ubsan' else {'UBSAN_OPTIONS':'halt_on_error=1'}),(v+'-helpers-token',None,'current-'+v,['--helpers-only','--token-mode'],{'ASAN_OPTIONS':'detect_leaks=0'} if v=='asan-ubsan' else {'UBSAN_OPTIONS':'halt_on_error=1'})]
 for n,binary,cur,args,opts in specs:
  out=G/'runs'/n;out.mkdir(parents=True,exist_ok=True);env=e.copy();env.update(opts);cmd=['python3',str(G/'preview-checkpoint.py'),*args,'--binary',str(G/'builds'/cur/'dmenu'),'--output',str(out),'--isolated-display']
  if binary:cmd += []
  run(n,cmd,env)
finally:
 p.terminate()
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill();p.wait()
 (G/'xvfb.stderr').write_bytes(p.stderr.read() if p.stderr else b'')
(G/'run-records.json').write_text(json.dumps(rec,indent=2)+'\n')
