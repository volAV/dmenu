import json,pathlib,re
G=pathlib.Path('/tmp/dmenu-fuzzy-integration-mclmbvjk/gui'); runs=json.loads((G/'recovery-run-records.json').read_text()); leak=json.loads((G/'leak-repro-records.json').read_text())
def result(label):
 d=G/'runs'/('recovery-'+label);rows=json.loads((d/'results.json').read_text());starts=0
 for row in rows:
  m=re.search(r'(?:unique_starts=|recorded starts=?)(\d+)',row)
  if m:starts=max(starts,int(m.group(1)))
 h=d/'helper.jsonl';helper_records=len(h.read_text().splitlines()) if h.exists() else 0
 p=d/'diagnostics/processes.jsonl';diag=[json.loads(x) for x in p.read_text().splitlines() if x] if p.exists() else []
 scan=0
 for item in diag:
  stderr=(d/'diagnostics'/item['stderr']).read_text(errors='replace')
  scan+=bool(re.search(r'AddressSanitizer|LeakSanitizer|UndefinedBehaviorSanitizer|runtime error:',stderr,re.I))
 lifecycle=[x for x in rows if any(k in x for k in ('repeated-request-resources','repeated-group-cleanup','no-preview-process-sampling','helper-window-destruction'))]
 return {'report':str(d/'report.txt'),'results_json':str(d/'results.json'),'pass_count':sum(x.startswith('PASS') for x in rows),'fail_count':sum(x.startswith('FAIL') for x in rows),'reported_helper_starts':starts,'synthetic_helper_invocations':helper_records,'process_diagnostic_records':len(diag),'sanitizer_diagnostic_count':scan,'lifecycle_resource_teardown_results':lifecycle,'group_observations_file':str(d/'group-observations.json'),'screenshots':len(list(d.glob('*.png')))}
warning={}
for f in (G/'logs').glob('compile-*.stderr'):
 vals=[line.split('warning:',1)[1].split('[')[0].strip() for line in f.read_text(errors='replace').splitlines() if 'warning:' in line]
 warning[f.name]={'count':len(vals),'categories':vals}
summary={'scope':'GUI verification of integration of reviewed fuzzy bounds fix','source_ids':{'original_baseline':'787050237a1b357e53efbec9ef5cc7870a51d041','corrected_pre_preview_sanitized_baseline':'32fafa2ce7daf1a683e3039bbaf7a9007823e986','current':'trial integration'},'configuration':'All source copies use copied trial/config.h. Main checkout and trial sources were not edited.','xvfb':{'binary':'/tmp/dmenu-preview-checkpoint-RBbWFs/xvfb/usr/bin/Xvfb','command':['Xvfb','-displayfd','FD','-screen','0','1280x900x24','-nolisten','tcp','-noreset'],'stderr':'recovery-xvfb.log (regular file)','probe_count':5,'probe_exit_codes':[x['exit_code'] for x in runs if x['name'].startswith('recovery-x-probe')]},'builds':{'compiler':'gcc','compile_flags':'-std=c99 -pedantic -g -O1 -fno-omit-frame-pointer -Wall -Wextra; sanitizer flags -fsanitize=address,undefined or -fsanitize=undefined','link_flags':'same sanitizer flags and -lX11 -lXinerama -lfontconfig -lXft -lm','logs':str(G/'logs'),'warning_counts_by_build':warning,'warning_analysis':'Four pre-existing -Wsign-compare warning sites; baseline lines 93,96,167,796 and integrated lines 391,394,504,1162 reflect line shifts. No new warning category observed.'},'runs':{k:result(k) for k in ['normal-full','normal-helpers-fuzzy','normal-helpers-token','asan-ubsan-full','asan-ubsan-helpers-token','ubsan-full','ubsan-helpers-token']},'exact_commands_and_environment':runs,'leak_and_reproducer':{'runner_command':['python3',str(G/'exit-and-repro.py')],'records_file':str(G/'leak-repro-records.json'),'cases':leak,'interpretation':'All three leak-enabled exit cases exit 1 with Fontconfig LeakSanitizer reports (8839 bytes, 128 allocations); not a clean leak claim. Original-baseline query a/item a exits 1 with UBSan OOB at dmenu.c:303; current prints a, exits 0, and has empty stderr.'},'initial_failed_attempts':{'cause':'Xvfb stderr PIPE was not drained while resets emitted xkb warnings, filling pipe and blocking server. Recovery used -noreset and file-backed stderr.','records':str(G/'run-records.json'),'preserved_logs':str(G/'logs'),'preserved_outputs':str(G/'runs')},'limitations':['Original baseline full sanitizer suite omitted because that source has the known fuzzy overflow; sanitized full runs compare against corrected pre-preview baseline.']}
(G/'gui-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
