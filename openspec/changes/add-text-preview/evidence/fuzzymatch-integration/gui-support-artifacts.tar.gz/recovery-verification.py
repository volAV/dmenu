#!/usr/bin/env python3
import ctypes,importlib.util,json,os,pathlib,subprocess,time
G=pathlib.Path('/tmp/dmenu-fuzzy-integration-mclmbvjk/gui');R=G.parent;X='/tmp/dmenu-preview-checkpoint-RBbWFs/xvfb/usr/bin/Xvfb'; rec=[]
def record(n,c,e,out,timeout=420):
 t=time.time()
 try:p=subprocess.run(c,env=e,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
 except subprocess.TimeoutExpired as x:p=subprocess.CompletedProcess(c,124,x.stdout or b'',(x.stderr or b'')+b'\nWATCHDOG TIMEOUT\n')
 (pathlib.Path(out+'.stdout')).write_bytes(p.stdout);(pathlib.Path(out+'.stderr')).write_bytes(p.stderr);rec.append({'name':n,'command':c,'environment':{k:e[k] for k in ('DISPLAY','ASAN_OPTIONS','UBSAN_OPTIONS','LC_ALL') if k in e},'exit_code':p.returncode,'duration_seconds':round(time.time()-t,2)});return p
r,w=os.pipe();log=open(G/'recovery-xvfb.log','wb');srv=subprocess.Popen([X,'-displayfd',str(w),'-screen','0','1280x900x24','-nolisten','tcp','-noreset'],pass_fds=(w,),stdout=subprocess.DEVNULL,stderr=log);os.close(w)
try:
 display=os.read(r,64).decode().strip();os.close(r);env=os.environ.copy();env.update(DISPLAY=':'+display,LC_ALL='C.UTF-8')
 # Check several X connections and tool access on this owned server.
 probe="import ctypes,os,subprocess; x=ctypes.CDLL('libX11.so.6'); x.XOpenDisplay.restype=ctypes.c_void_p; d=x.XOpenDisplay(None); assert d; x.XCloseDisplay(ctypes.c_void_p(d)); subprocess.run(['xdotool','getdisplaygeometry'],check=True,stdout=subprocess.PIPE); print(os.environ['DISPLAY'])"
 for i in range(5): record(f'recovery-x-probe-{i}', ['python3','-c',probe],env,str(G/'logs'/f'recovery-x-probe-{i}'))
 specs=[('normal-full','current-normal',['--baseline',str(G/'builds/original-baseline-normal/dmenu')],{}),('normal-helpers-fuzzy','current-normal',['--helpers-only'],{}),('normal-helpers-token','current-normal',['--helpers-only','--token-mode'],{})]
 for v in ('asan-ubsan','ubsan'):
  opt={'ASAN_OPTIONS':'detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1'} if v=='asan-ubsan' else {'UBSAN_OPTIONS':'halt_on_error=1'}
  specs += [(v+'-full','current-'+v,['--baseline',str(G/'builds'/('corrected-baseline-'+v)/'dmenu')],opt),(v+'-helpers-token','current-'+v,['--helpers-only','--token-mode'],opt)]
 for n,build,args,opts in specs:
  outdir=G/'runs'/('recovery-'+n);outdir.mkdir(parents=True,exist_ok=True);e=env.copy();e.update(opts);c=['python3',str(G/'preview-checkpoint.py'),*args,'--binary',str(G/'builds'/build/'dmenu'),'--output',str(outdir),'--isolated-display'];record(n,c,e,str(G/'logs'/('recovery-'+n)))
finally:
 srv.terminate()
 try:srv.wait(timeout=5)
 except subprocess.TimeoutExpired:srv.kill();srv.wait()
 log.close()
(G/'recovery-run-records.json').write_text(json.dumps(rec,indent=2)+'\n')
