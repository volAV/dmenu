#!/usr/bin/env python3
import importlib.util,json,os,pathlib,subprocess,sys,time
G=pathlib.Path('/tmp/dmenu-fuzzy-integration-mclmbvjk/gui'); spec=importlib.util.spec_from_file_location('harness',G/'preview-checkpoint.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
X='/tmp/dmenu-preview-checkpoint-RBbWFs/xvfb/usr/bin/Xvfb';r,w=os.pipe();log=open(G/'exit-xvfb.log','wb');server=subprocess.Popen([X,'-displayfd',str(w),'-screen','0','1280x900x24','-nolisten','tcp','-noreset'],pass_fds=(w,),stdout=subprocess.DEVNULL,stderr=log);os.close(w);records=[]
try:
 display=os.read(r,64).decode().strip();os.close(r);base=os.environ.copy();base.update(DISPLAY=':'+display,LC_ALL='C.UTF-8');os.environ.update(DISPLAY=base['DISPLAY'],LC_ALL='C.UTF-8')
 for label in ('original-baseline','corrected-baseline','current'):
  exe=G/'builds'/(label+'-asan-ubsan')/'dmenu';env=base.copy();env.update(ASAN_OPTIONS='detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1');menu=h.invoke(str(exe),[],b'alpha\n',env)
  try:
   actual=menu.finish('Return'); records.append({'case':label,'command':[str(exe)],'environment':{'DISPLAY':base['DISPLAY'],'ASAN_OPTIONS':'detect_leaks=1','UBSAN_OPTIONS':'halt_on_error=1'},'stdout':actual[0].decode(errors='replace'),'status':actual[1],'stderr':actual[2]})
  finally: menu.close()
 # GUI query=a, one label=a, Return for current and original baseline.
 for label in ('original-baseline','current'):
  exe=G/'builds'/(label+('-asan-ubsan' if label=='current' else '-normal'))/'dmenu'
  # Use instrumented current; original normal is used only if ASan baseline build is unavailable.
  if label=='original-baseline':exe=G/'builds/original-baseline-asan-ubsan/dmenu'
  env=base.copy();env.update(ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1');menu=h.invoke(str(exe),[],b'a\n',env)
  try:
   menu.key('a');actual=menu.finish('Return');records.append({'case':label+'-query-a-item-a','command':[str(exe)],'environment':{'DISPLAY':base['DISPLAY'],'ASAN_OPTIONS':'detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1'},'stdout':actual[0].decode(errors='replace'),'status':actual[1],'stderr':actual[2]})
  finally:menu.close()
finally:
 server.terminate()
 try:server.wait(timeout=5)
 except subprocess.TimeoutExpired:server.kill();server.wait()
 log.close()
(G/'leak-repro-records.json').write_text(json.dumps(records,indent=2)+'\n')
