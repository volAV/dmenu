import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/home/avo/Projects/private/dmenu-preview-next')
w = Path('/tmp/dmenu-preview-4a-tttbbkv1')
spec = importlib.util.spec_from_file_location('checkpoint', root/'tests/preview-checkpoint.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
r = subprocess.run(['make', 'CC=cc -Wextra'], cwd=w/'font', capture_output=True, text=True)
(w/'font-build.log').write_text(r.stdout+r.stderr)
assert r.returncode == 0
helper = w/'font-helper.py'
helper.write_text('#!/usr/bin/python3\nimport os,sys\nsys.stdin.buffer.read()\nsys.stdout.buffer.write(("A\\n\\nB\\n" if os.getenv("SAFE_FONT_TEXT") else ("😀" if os.getenv("NARROW_FONT") else "😀😀😀")+"\\n\\n中 Ελληνικά\\n").encode())\n')
helper.chmod(0o700)
xlog = (w/'font-xvfb.log').open('w')
rfd, wfd = os.pipe()
s = subprocess.Popen(['/tmp/dmenu-preview-checkpoint-RBbWFs/xvfb/usr/bin/Xvfb','-displayfd',str(wfd),'-screen','0','1920x1080x24','-nolisten','tcp','-noreset'],pass_fds=(wfd,),stdout=xlog,stderr=xlog)
os.close(wfd)
narrow = bool(os.environ.get('NARROW_FONT'))
tag = 'font-narrow' if narrow else 'font'
parent = None
try:
    with os.fdopen(rfd) as f:
        os.environ['DISPLAY'] = ':' + f.readline().strip()
    env = dict(os.environ, LC_ALL='C.UTF-8')
    if narrow:
        xlib, parent_display, parent = h.parent_window(80, 140)
    images = []
    for safe in (False, True):
        menu = h.Menu(str(w/'font/dmenu'), ['-P',str(helper),'-l','6', *(['-w',hex(parent)] if parent else [])], b'alpha\nbeta\n', {**env, **({'SAFE_FONT_TEXT':'1'} if safe else {})})
        try:
            menu.wait_window()
            time.sleep(.3)
            image = w/(tag + ('-safe.png' if safe else '-clipped.png'))
            menu.screenshot(image)
            g = menu.info()
            images.append(image)
            menu.key('Return')
            assert menu.process.wait(timeout=2) == 0
            assert menu.stdout_bytes() == b'alpha\n'
            assert not menu.stderr_text()
        finally:
            menu.close()
    row = g['Height']//7
    pane = (g['Width']-1)*2//5+1
    regions = [(0,0,g['Width'],row),(0,row,pane,6*row),(pane,6*row,g['Width']-pane,row),(pane,2*row,g['Width']-pane,row)]
    for region in regions:
        assert h.region_signature(images[0],*region)[1] == h.region_signature(images[1],*region)[1], region
    assert h.region_signature(images[0],pane,row,g['Width']-pane,row)[0] > 0
    result = {'result':'passed','fonts':['Liberation Mono:size=8','DejaVu Sans:size=48'],'geometry':g,'protected_regions':regions,'stdout':'alpha\n','screenshots':list(map(str,images))}
    (w/(tag+'-result.json')).write_text(json.dumps(result,indent=2))
    print('PASS actual oversized fallback-font ink confinement, blank-row isolation, input/list/footer equality and selected-label output; row height',row)
finally:
    if parent:
        xlib.XDestroyWindow.argtypes = [h.ctypes.c_void_p, h.ctypes.c_ulong]
        xlib.XDestroyWindow(parent_display, parent)
        xlib.XCloseDisplay.argtypes = [h.ctypes.c_void_p]
        xlib.XCloseDisplay(parent_display)
    s.terminate()
    s.wait(timeout=10)
    xlog.close()
