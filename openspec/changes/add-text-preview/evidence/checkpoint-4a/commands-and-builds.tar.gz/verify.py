import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/home/avo/Projects/private/dmenu-preview-next')
WORK = Path('/tmp/dmenu-preview-4a-tttbbkv1')
BASEFLAGS = ['-std=c99', '-pedantic', '-Wall', '-Wextra', '-g', '-O1', '-fno-omit-frame-pointer', '-D_DEFAULT_SOURCE', '-D_XOPEN_SOURCE=700', '-DVERSION="5.4"', '-DXINERAMA', '-I/usr/include/freetype2']
LIBS = ['drw.c', 'util.c', '-lX11', '-lXinerama', '-lfontconfig', '-lXft', '-lm']
VARIANTS = {'normal': [], 'ubsan': ['-fsanitize=undefined', '-fno-sanitize-recover=all'], 'asan': ['-fsanitize=address,undefined', '-fno-sanitize-recover=all', '-fno-pie', '-no-pie']}

def run(name, argv, cwd=ROOT, env=None, timeout=240):
    start = time.monotonic()
    try:
        r = subprocess.run(list(map(str, argv)), cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
        text, status = r.stdout, r.returncode
    except subprocess.TimeoutExpired as e:
        text, status = str(e.stdout), 124
    (WORK / (name + '.log')).write_text(text)
    print(name, 'exit', status, 'seconds', round(time.monotonic()-start, 3), 'PASS', sum(x.startswith('PASS') for x in text.splitlines()), flush=True)
    if status:
        print(text[-6000:], flush=True)
        raise SystemExit(status)
    return text

if sys.argv[1] == 'build':
    for variant, extra in VARIANTS.items():
        d = WORK / variant
        d.mkdir(exist_ok=True)
        (d / 'tests').mkdir(exist_ok=True)
        for f in ROOT.iterdir():
            if f.name in ('Makefile', 'config.mk') or f.suffix in ('.c', '.h'):
                if f.name != 'config.h':
                    shutil.copy2(f, d / f.name)
        for f in (ROOT / 'tests').glob('*.c'):
            shutil.copy2(f, d / 'tests' / f.name)
        run(variant + '-build', ['make', 'CC=cc -Wextra -g -fno-omit-frame-pointer ' + ' '.join(extra)], cwd=d)
        if os.environ.get('PROD_ONLY'):
            continue
        for probe in ('preview-boundary', 'fuzzymatch', 'preview-text'):
            run(variant + '-' + probe + '-build', ['cc', *BASEFLAGS, *extra, 'tests/' + probe + '.c', *LIBS, '-o', probe], cwd=d)
    print('Builds ready', flush=True)

if sys.argv[1] == 'native':
    for variant in VARIANTS:
        env = dict(os.environ, ASAN_OPTIONS='detect_leaks=1', UBSAN_OPTIONS='halt_on_error=1', PREVIEW_TEST_HELPER=str(WORK/'normal'/'preview-boundary'), PREVIEW_TEXT_HELPER=str(WORK/'normal'/'preview-text'))
        for probe in ('preview-boundary', 'fuzzymatch', 'preview-text'):
            run(variant + '-' + probe, [WORK/variant/probe], env=env, timeout=30)
        run(variant+'-fuzzy-reproducer', [WORK/variant/'fuzzymatch', 'a', 'a'], env=env, timeout=10)

if sys.argv[1] == 'gui':
    xlog = (WORK/'xvfb.log').open('w')
    rfd, wfd = os.pipe()
    server = subprocess.Popen(['/tmp/dmenu-preview-checkpoint-RBbWFs/xvfb/usr/bin/Xvfb', '-displayfd', str(wfd), '-screen', '0', '1920x1080x24', '-nolisten', 'tcp', '-noreset'], pass_fds=(wfd,), stdout=xlog, stderr=xlog)
    os.close(wfd)
    try:
        with os.fdopen(rfd) as f:
            display = ':' + f.readline().strip()
        assert display != ':' and server.poll() is None
        env = dict(os.environ, DISPLAY=display, ASAN_OPTIONS='detect_leaks=0', UBSAN_OPTIONS='halt_on_error=1')
        for _ in range(5):
            run('display-probe', ['xdotool', 'getdisplaygeometry'], env=env, timeout=5)
        variants = sys.argv[2:] or list(VARIANTS)
        for variant in variants:
            if not os.environ.get('TEXT_ONLY'):
                suffix = 'gui-token' if os.environ.get('TOKEN_ONLY') else 'gui-full'
                options = ['--helpers-only', '--token-mode'] if os.environ.get('TOKEN_ONLY') else []
                run(variant+'-'+suffix, ['python3', ROOT/'tests/preview-checkpoint.py', '--baseline', WORK/'baseline/dmenu', '--binary', WORK/variant/'dmenu', '--output', WORK/(variant+'-'+suffix), '--isolated-display', *options], env=env, timeout=300)
            if not os.environ.get('SKIP_TEXT'):
                run(variant+'-gui-text', ['python3', ROOT/'tests/preview-text.py', '--binary', WORK/variant/'dmenu', '--layout-probe', WORK/variant/'preview-text', '--output', WORK/(variant+'-gui-text'), '--isolated-display'], env=env, timeout=120)
    finally:
        server.terminate()
        server.wait(timeout=10)
        xlog.close()
