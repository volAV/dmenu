import difflib
import hashlib
import json
import os
from pathlib import Path
import random
import re
import shlex
import shutil
import subprocess
import tarfile

ROOT = Path('/tmp/dmenu-fuzzy-integration-mclmbvjk')
MAIN = Path('/home/avo/Projects/private/dmenu')
OUT = ROOT / 'headless'
OUT.mkdir()
commands = []
env = dict(os.environ, ASAN_OPTIONS='detect_leaks=1', UBSAN_OPTIONS='halt_on_error=1')
flags = ['-std=c99', '-pedantic', '-Wall', '-Wextra', '-g', '-O1', '-fno-omit-frame-pointer',
         '-D_DEFAULT_SOURCE', '-D_XOPEN_SOURCE=700', '-DVERSION="5.4"', '-DXINERAMA', '-I/usr/include/freetype2']
libs = ['-lX11', '-lXinerama', '-lfontconfig', '-lXft', '-lm']

def run(cmd, cwd, log, expected=0, process_env=env):
    result = subprocess.run(list(map(str, cmd)), cwd=cwd, env=process_env, capture_output=True, timeout=15)
    (OUT / (log + '.stdout')).write_bytes(result.stdout)
    (OUT / (log + '.stderr')).write_bytes(result.stderr)
    commands.append({'command': shlex.join(list(map(str, cmd))), 'cwd': str(cwd),
                     'env': {k: process_env.get(k) for k in ['ASAN_OPTIONS', 'UBSAN_OPTIONS', 'PREVIEW_TEST_HELPER']},
                     'exit': result.returncode, 'stdout': log + '.stdout', 'stderr': log + '.stderr'})
    if expected is not None:
        assert result.returncode == expected, (log, result.returncode, result.stderr.decode(errors='replace'))
    return result

with tarfile.open(ROOT / 'checkout-before.tar.gz') as archive:
    pre_source = archive.extractfile('dmenu/dmenu.c').read()

for variant in ['pre', 'post']:
    src = OUT / variant
    src.mkdir()
    (src / 'tests').mkdir()
    for name in ['dmenu.c', 'drw.c', 'util.c', 'drw.h', 'util.h', 'config.def.h', 'config.mk', 'Makefile', 'arg.h']:
        shutil.copy2(MAIN / name, src / name)
    for name in ['fuzzymatch.c', 'preview-boundary.c']:
        shutil.copy2(MAIN / 'tests' / name, src / 'tests' / name)
    if variant == 'pre':
        (src / 'dmenu.c').write_bytes(pre_source)
    # Fresh-checkout prerequisite, before any standalone build.
    assert not (src / 'config.h').exists()
    run(['make', 'config.h'], src, variant + '-config')
    assert (src / 'config.h').read_bytes() == (src / 'config.def.h').read_bytes()
    for mode, sanitizers in [('normal', []), ('asan', ['-fsanitize=address,undefined']), ('ubsan', ['-fsanitize=undefined'])]:
        for target, sources in [('dmenu', ['dmenu.c']), ('fuzzy', ['tests/fuzzymatch.c'])]:
            run(['cc', *flags, *sanitizers, *sources, 'drw.c', 'util.c', *libs, '-o', str(src / (target + '-' + mode))],
                src, variant + '-' + target + '-' + mode + '-build')
    if variant == 'post':
        for mode, sanitizers in [('normal', []), ('asan', ['-fsanitize=address,undefined']), ('ubsan', ['-fsanitize=undefined'])]:
            run(['cc', *flags, *sanitizers, 'tests/preview-boundary.c', 'drw.c', 'util.c', *libs,
                 '-o', str(src / ('boundary-' + mode))], src, 'boundary-' + mode + '-build')

pre, post = OUT / 'pre', OUT / 'post'
red = run([pre / 'fuzzy-asan', 'a', 'a'], pre, 'original-minimal-asan', expected=None,
          process_env=dict(env, UBSAN_OPTIONS='halt_on_error=0'))
assert red.returncode != 0 and b'heap-buffer-overflow' in red.stderr and b'fuzzymatch' in red.stderr
red_ub = run([pre / 'fuzzy-ubsan', 'a', 'a'], pre, 'original-minimal-ubsan', expected=None)
assert red_ub.returncode != 0 and b'runtime error:' in red_ub.stderr
for mode in ['asan', 'ubsan', 'normal']:
    run([post / ('fuzzy-' + mode)], post, 'explicit-score-order-' + mode)
    run([post / ('fuzzy-' + mode), 'a', 'a'], post, 'fixed-minimal-' + mode)

# Same production probe, same representative inputs, byte-exact indices/scores/order.
cases = [
    ('empty-items', '', []), ('empty-items-query', 'a', []),
    ('zero', 'z', ['alpha', 'beta']), ('one', 'a', ['a']),
    ('multiple', 'ab', ['axb', 'zzab', 'ab', 'no']),
    ('all', 'a', ['a', 'ba', 'za', 'aab']),
    ('duplicates', 'ab', ['ab', 'ab', 'ab', 'axb']),
    ('empty-query', '', ['alpha', 'beta', 'alpha', '']),
    ('no-subsequence', 'zzzz', ['alpha', 'beta']),
    ('case', 'AB', ['ab', 'Ab', 'AB', 'aB', 'XAXB']),
    ('tokens', 'ab cd', ['ab cd', 'cd ab', 'abXcd', 'AB CD', 'no']),
    ('long-query', 'a' * 8000, ['a' * 8000, 'z' * 128 + 'a' * 8000, 'a' * 7999]),
    ('long-label', 'az', ['a' + 'x' * 60000 + 'z', 'az', 'x' * 64000]),
]
rng = random.Random(721)
for i in range(24):
    cases.append(('seeded-' + str(i), ''.join(rng.choices('abCD', k=rng.randrange(5))),
                  [''.join(rng.choices('abCDxy ', k=rng.randrange(20))) for _ in range(16)]))
rows = []
for name, query, labels in cases:
    for options in [[], ['-i'], ['-F'], ['-F', '-i']]:
        key = name + '-' + ('-'.join(options).replace('-', '') or 'fuzzy')
        args = [*options, '--', query, *labels]
        baseline = run([pre / 'fuzzy-normal', *args], pre, key + '-before')
        expected = baseline.stdout
        for mode in ['normal', 'asan', 'ubsan']:
            result = run([post / ('fuzzy-' + mode), *args], post, key + '-after-' + mode)
            assert result.stdout == expected, key
            assert b'runtime error:' not in result.stderr and b'ERROR: AddressSanitizer' not in result.stderr, key
        rows.append({'case': name, 'options': options, 'result_sha256': hashlib.sha256(expected).hexdigest(),
                     'matches': len(expected.splitlines()), 'equal_stdout_exit_and_scores': True})

boundary = []
for mode in ['normal', 'asan', 'ubsan']:
    result = run([post / ('boundary-' + mode)], post, 'boundary-' + mode,
                 process_env=dict(env, PREVIEW_TEST_HELPER=str(post / 'boundary-normal')))
    boundary.append({'mode': mode, 'exit': result.returncode, 'reports': result.stdout.decode().splitlines()})

warnings = {}
for mode in ['normal', 'asan', 'ubsan']:
    for target in ['dmenu', 'fuzzy']:
        a = (OUT / ('pre-' + target + '-' + mode + '-build.stderr')).read_text()
        b = (OUT / ('post-' + target + '-' + mode + '-build.stderr')).read_text()
        # Same pre-integration/current source line numbers; include seam names match.
        assert a == b, (target, mode, list(difflib.unified_diff(a.splitlines(), b.splitlines())))
        warnings[target + '-' + mode] = [line for line in b.splitlines() if 'warning:' in line]

for name in ['README', 'dmenu.c', 'tests/fuzzymatch.c']:
    assert (MAIN / name).read_bytes() == (ROOT / 'trial' / name).read_bytes(), name
summary = {'pre_source_sha256': hashlib.sha256(pre_source).hexdigest(),
           'post_source_sha256': hashlib.sha256((MAIN / 'dmenu.c').read_bytes()).hexdigest(),
           'original_asan_exit': red.returncode, 'original_ubsan_exit': red_ub.returncode,
           'matrix_rows': rows, 'boundary': boundary, 'warnings_identical': warnings,
           'standalone_fresh_config_prerequisite_passed': True, 'trial_matches_main': True,
           'commands': commands}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps({'matrix_variants': len(rows), 'corrected_runs': len(rows) * 3,
                  'boundary_modes': len(boundary), 'commands': len(commands),
                  'original_asan_exit': red.returncode, 'original_ubsan_exit': red_ub.returncode,
                  'warnings_per_app_build': len(warnings['dmenu-normal']), 'status': 'PASS'}))
