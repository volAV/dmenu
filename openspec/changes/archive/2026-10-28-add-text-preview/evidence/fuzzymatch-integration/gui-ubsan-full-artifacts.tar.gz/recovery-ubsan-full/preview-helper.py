#!/usr/bin/python3
import hashlib, json, os, subprocess, sys, time
mode = os.environ.get("PREVIEW_MODE", "content")
def extra_fds():
    result = []
    for fd in os.listdir("/proc/self/fd"):
        if fd not in ("0", "1", "2"):
            try:
                os.readlink("/proc/self/fd/" + fd)
                result.append(fd)
            except FileNotFoundError:
                pass
    return result
line = sys.stdin.buffer.readline() if mode not in ("no-read", "partial-input", "early-success") else b""
label = line[:-1].decode("utf-8", "replace") if line.endswith(b"\n") else line.decode("utf-8", "replace")
stdin_line_ends_lf = line.endswith(b"\n")
stdin_eof = sys.stdin.buffer.read(1) == b"" if mode not in ("no-read", "partial-input", "early-success") else False
env_digest = hashlib.sha256(json.dumps(sorted(os.environ.items()), separators=(",", ":")).encode()).hexdigest()
record = {"argv": sys.argv, "label": label, "stdin_line_ends_lf": stdin_line_ends_lf, "stdin_eof": stdin_eof, "environment": sorted(os.environ), "environment_digest": env_digest, "label_in_environment": any(label and label in value for value in os.environ.values()), "extra_fds": extra_fds(), "stderr_target": os.readlink("/proc/self/fd/2"), "pid": os.getpid(), "pgid": os.getpgrp(), "started_monotonic": time.monotonic()}
with open(os.environ["PREVIEW_LOG"], "a", encoding="utf-8") as log:
    log.write(json.dumps(record, ensure_ascii=False) + "\n")
    log.flush()
os.write(2, b"synthetic stderr must be discarded\n")
if mode == "no-read":
    time.sleep(2)
elif mode == "partial-input":
    sys.stdin.buffer.read(1)
    os.close(0)
    sys.stdout.write("partial input\n")
    sys.exit(7)
elif mode == "early-success":
    os.close(0)
    sys.stdout.write("early success\n")
elif mode == "delay-output":
    time.sleep(.5)
    sys.stdout.write("delayed\n")
elif mode == "delay-exit":
    sys.stdout.write("finished\n")
    sys.stdout.flush()
    time.sleep(.2)
elif mode == "stale":
    time.sleep(float(os.environ.get("PREVIEW_DELAY", ".25")))
    sys.stdout.write({"blue": "Unicode λ雪🙂\n", "red": "red preview\n", "green": "green preview\n"}.get(label, label))
elif mode == "close-stdout":
    sys.stdout.write("closed\n")
    sys.stdout.flush()
    os.close(1)
    time.sleep(2)
elif mode == "unlimited":
    while True:
        os.write(1, b"x" * 4096)
elif mode == "continuous":
    while True:
        os.write(1, b"bounded preview traffic\n")
        time.sleep(.04)
elif mode == "nonzero":
    sys.stdout.write("discard me\n")
    sys.exit(7)
elif mode == "empty":
    pass
elif mode == "truncate":
    sys.stdout.buffer.write(b"x" * int(os.environ["PREVIEW_BYTES"]))
    sys.stdout.buffer.flush()
    sys.exit(int(os.environ.get("PREVIEW_EXIT", "0")))
elif mode == "descendant-pipe":
    subprocess.Popen([sys.executable, "-c", "import time; time.sleep(30)"])
    sys.stdout.write("leader\n")
elif mode == "descendant-exit":
    child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(30)"],
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
    sys.stdout.write("leader\n")
    sys.stdout.flush()
elif mode == "content":
    outputs = {
        "alpha": "Alpha preview\nsecond line\n\nparagraph\n",
        "βeta": "Unicode λ雪🙂\n",
        "white space;$(touch nope)": "Literal label\n",
        "No preview": "No preview\n",
        "Unavailable": "Unavailable\n",
        "Timed out": "Timed out\n",
        "Truncated": "Truncated\n",
        "Loading": "Loading\n",
        "row-label": "first line\nsecond line\n",
        "first line": "first line\n",
        "red": "red preview\n",
        "green": "Green preview\nsecond line\n\nparagraph\n",
        "blue": "Unicode λ雪🙂\n",
        "x": "x preview\n",
    }
    sys.stdout.write(outputs.get(label, "selected: " + label + "\n"))

