#define main dmenu_application_main
#include "/tmp/preview-native-0x2eGC/local/dmenu.c"
#undef main
#include <assert.h>
#include <malloc.h>
int main(void) {
    size_t used, display_bytes, row_bytes;
    assert(!preview.buf && !preview.display && !preview.rows && !preview.pid);
    preview.buf = ecalloc(PREVIEWMAX + 1, 1);
    for (used = 0; used <= PREVIEWMAX; used += 1024) {
        preview.used = used;
        previewprepare_start(100);
        display_bytes = malloc_usable_size(preview.display);
        row_bytes = malloc_usable_size(preview.rows);
        assert(display_bytes >= used * 4 + 1 && display_bytes <= used * 4 + 4096);
        assert(row_bytes >= (used * 4 + 1) * sizeof(size_t));
        assert(row_bytes <= (used * 4 + 1) * sizeof(size_t) + 4096);
    }
    printf("raw=%zu display=%zu rows=%zu raw_limit=%d size_t=%zu\n", malloc_usable_size(preview.buf), display_bytes, row_bytes, PREVIEWMAX, sizeof(size_t));
    previewprepare_reset(); free(preview.buf); return 0;
}
