# Checkpoint 6B: task 6.2 evidence

This package closes technical task 6.2 at HEAD
`fcfc851f9077bc9a0b754619d78369cf45293545`, with the independently
reviewed DISPLAY isolation protocol exception below. Packaging did not run any
application, sanitizer, GUI, stress or lifecycle verification. Tasks 6.3-6.5,
installation and deployment are not authorized by this package.

## Evidence index

| Finding | Primary artifacts |
|---|---|
| Build flags, four successful warning-enabled builds, four existing warnings each; native ASan/UBSan | `summary.json`; `native/toolchain.txt`; each native variant's `evidence/full-build.log`, boundary/text timed logs and exit/timing records, fuzzy logs; sanitized probe build logs |
| Focused GUI address/undefined safety, FDs, RSS, direct children | `root/gui.py`; `root/gui-normal/results.json`; `root/gui-ubsan-final/results.json`; `root/gui-asan-bounded/results.json`; each run's groups, helper records and per-process diagnostics |
| Default quarantine failure, not PASS | `root/gui-asan-final.stderr`; partial `root/gui-asan-final/results.json` and groups/helper records; `harness/default-quarantine-driver.py` records `detect_leaks=0` without quarantine overrides |
| Bounded quarantine success and its limits | `root/run-final.py`; `root/gui-asan-bounded/results.json`; `root/resource-summary.json` |
| SIGKILL dispatch and cooperative-group cleanup | `root/trace.py`; `root/trace/results.json`; five raw `.trace` files and associated helper records |
| No-preview idle/no allocated preview state | `root/trace/idle.trace`; `root/gdb-no-preview.stdout`; each accepted GUI run's no-preview samples |
| Requested allocation bounds versus allocator rounding | `allocation.c`; `allocation-command.json`; `allocation-build.log`; `allocation-run.log` |
| Real-Xft sanitizer clipping checks | `root/clip-asan-check.stdout`; `root/clip-ubsan-check.stdout` and their stderr |
| Known Fontconfig/Xft exit leak | `leaks-final/no-preview.stderr`; `leaks-final/preview.stderr`; `leaks-final/results.json`; selected historical `leaks-final/original-baseline-record.json` and `leaks-final/original-baseline.stderr` |
| Failed and corrected DISPLAY probes | Four files under `protocol/`; `harness/menu-excerpts.txt`; `leaks/diagnostics/processes.jsonl`; `leaks-final/diagnostics/processes.jsonl` |

`summary.json` contains a machine-readable evidence map with explicit archive-relative
file links, configurations, derived measurements and limitations. `manifest.json`
lists every other member, its source, transformation and SHA256. Paths in raw
compiler output and exact historical drivers describe their original workspaces;
they are not unresolved archive links. The production source and full test harness
remain available at the identified repository HEAD, not duplicated here.

## DISPLAY protocol exception and independent closure

The excluded leak attempt set DISPLAY only in the menu environment. Python kept
its inherited working DISPLAY; `Menu.wait_window()` launched `xdotool search
--onlyvisible --class dmenu` with that inherited environment. The owned Xvfb
process also inherited the variable, but was an independently created server;
its inheritance is not evidence that it acted as a client of the working server.
The menu itself used owned Xvfb. The execution record shows `menu window did not
appear` inside `invoke()` before `finish('Return')`: no successful window search,
key injection, screenshot or clipboard/selection interaction followed. Only the
no-preview menu started, then forced cleanup killed it (status -9). No preview
helper ran in that attempt. There is no per-query execution log: exact query
count and server-side completion of individual searches cannot be recovered.

The corrected driver sets `os.environ['DISPLAY']` to the newly allocated owned
Xvfb before invoking any X client. Both menus and the inherited-environment
xdotool calls therefore used that owned server; Xvfb termination is in `finally`.
Its two leak-enabled exits completed and are diagnostic comparisons, not clean
PASS results: both returned 1 and reported 8839 bytes in 128 allocations.

`protocol/failed-driver.py` and `protocol/corrected-driver.py` are exact code
strings recovered from the original tool inputs, not reconstructed programs.
Their execution JSON files preserve the exact parsed tool-call and tool-result
objects, timestamps, transcript filename and source line numbers. The unrelated
syntax-error input preceding the real failed attempt is excluded. The dependency
excerpts preserve verbatim `run`, `Menu` and cleanup/diagnostic control flow.

Independent review accepted the technical task and bounded the violation to the
window-search path; the user authorized closure with this explicit exception.
Neither this review nor corrected verification makes the original attempt fully
protocol-compliant. The failed attempt contributes no PASS coverage.

## Scope and limitations

- Normal, UBSan and bounded-quarantine ASan each completed 14 focused cases with
  157 timely group observations. This is not a rerun or substitute claim for the
  earlier 90-case/201-helper suite. Repeated churn has 48 selection changes and
  49 helper starts per workload. Resource and zombie observations are sampled.
- Default ASan quarantine failed the overflow RSS budget: 8808-12467 pages against
  a 2048-page span budget. The partial results stop after idle and blocked-helper
  workloads; full failed overflow samples were not retained. Preserve the raw
  traceback range, not an invented sample series. The final GUI harness snapshot
  includes a later sample-save improvement and is not an exact source snapshot
  of the failed run. The original failure and default driver remain distinct.
- Bounded ASan uses `detect_leaks=0:quarantine_size_mb=4:thread_local_quarantine_size_kb=64`.
  Address/undefined checks remain enabled; post-warmup RSS spans including
  settlement are 135/27/328 pages. This does not establish default-quarantine RSS
  stability or GUI leak cleanliness. Native ASan retains leak detection and uses
  normal uninstrumented producers for sanitized parent probes.
- Leak-enabled final preview/no-preview stderr are identical after PID/address
  normalization. One individual historical original-baseline diagnostic is kept
  solely to support the known pre-existing 8839-byte/128-allocation comparison;
  no historical archive or unrelated reproducer is included.
- Trace-based group timings (78.6/19.6/25.7/19.2 ms) are observation upper bounds
  after successful SIGKILL dispatch, using realtime timestamps; monotonic group
  checks conservatively include runtime before cancellation. Key-driver exit
  timings include injection overhead and its 50 ms sleep. No instantaneous
  disappearance or deliberate escape containment is claimed.
- Valgrind was unavailable. OpenBSD, physical monitors, manual Xmonad and deliberate
  group escape containment were not tested. The optional debugger allocation
  breakpoint timed out and is excluded; the included allocation probe supplies
  the allocation observation. Allocator rounding is not the requested ceiling.
- The initial before-manifest was lost. No complete before/after SHA256 preservation
  claim is made for original untracked files. Initial source-copy omissions,
  startup-warmup and clip-argument mistakes remain excluded harness failures;
  their unrelated/superseded experiments are not packaged.

## Selection, redaction and integrity

No measurements, statuses, timestamps, failure messages or diagnostic stacks were
edited. Helper JSONL files retain every record but remove `argv`, `environment`
(variable names only) and `environment_digest`; these are unnecessary host metadata.
Every such transformation and original input SHA256 is recorded in the manifest.
JSON serialization changes whitespace/key ordering only. Generated `summary.json`
selects original results and derives counts/ranges; it is not an original execution
record. The historical baseline record selects one case and points to its verbatim
stderr field. The index, summary and manifest were authored during packaging.

Exact drivers/execution records, diagnostic stacks and allocation source retain
original absolute paths where needed for forensic fidelity. PID/PGID values are
retained only for lifecycle/trace/diagnostic correlation. Unnecessary preservation
manifests, host/index-status snapshots, environment lists/digests, duplicate source
snapshots, generated binaries, images, nested archives and earlier checkpoint
bundles are excluded. No full environment values were captured or added. The
retained sanitizer environment options are deliberate test configuration, not
credentials. Archive entry metadata has UID/GID/mtime zero and no user/group names.
