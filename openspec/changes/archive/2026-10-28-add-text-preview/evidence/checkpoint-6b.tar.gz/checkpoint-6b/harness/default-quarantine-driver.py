import subprocess,os,select,json
from pathlib import Path
w=Path('/tmp/.ctx-mode-m95vl7/dmenu-6b-63on7vuy'); r,fd=os.pipe(); log=(w/'xvfb-3.stderr').open('wb'); x=subprocess.Popen(['/tmp/dmenu-preview-checkpoint-RBbWFs/xvfb/usr/bin/Xvfb','-displayfd',str(fd),'-screen','0','1024x768x24','-nolisten','tcp','-noreset'],pass_fds=(fd,),stdout=subprocess.DEVNULL,stderr=log);os.close(fd)
try:
 assert select.select([r],[],[],10)[0]; display=':'+os.read(r,32).decode().strip();os.close(r);env={**os.environ,'DISPLAY':display,'ASAN_OPTIONS':'detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
 jobs=[('trace-final',['python3',str(w/'trace.py')])]
 for kind,build in [('asan','asan-local'),('ubsan','ubsan-default')]:
  jobs.append(('gui-'+kind+'-final',['python3',str(w/'gui.py'),'--repo','/home/avo/Projects/private/dmenu-preview-next','--binary','/tmp/preview-native-0x2eGC/'+build+'/dmenu','--output',str(w/('gui-'+kind+'-final'))]))
  clip=w/('clip-'+kind+'-images');clip.mkdir();jobs.append(('clip-'+kind+'-final',['/tmp/preview-native-0x2eGC/'+build+'/preview-clip',str(clip)]))
 for name,cmd in jobs:
  p=subprocess.run(cmd,env=env,capture_output=True,timeout=110);(w/(name+'.stdout')).write_bytes(p.stdout);(w/(name+'.stderr')).write_bytes(p.stderr);print(name,'exit',p.returncode,p.stdout.decode()[-2200:],p.stderr.decode()[-1500:])
finally:
 x.terminate();x.wait(timeout=5);log.close()