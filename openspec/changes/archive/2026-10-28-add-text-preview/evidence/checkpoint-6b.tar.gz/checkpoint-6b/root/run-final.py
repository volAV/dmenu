import os,subprocess,select,json
from pathlib import Path
w=Path(__file__).parent
r,fd=os.pipe();log=(w/'xvfb-final.stderr').open('wb');x=subprocess.Popen(['/tmp/dmenu-preview-checkpoint-RBbWFs/xvfb/usr/bin/Xvfb','-displayfd',str(fd),'-screen','0','1024x768x24','-nolisten','tcp','-noreset'],pass_fds=(fd,),stdout=subprocess.DEVNULL,stderr=log);os.close(fd)
try:
    assert select.select([r],[],[],10)[0];display=':'+os.read(r,32).decode().strip();os.close(r)
    env={**os.environ,'DISPLAY':display,'ASAN_OPTIONS':'detect_leaks=0:quarantine_size_mb=4:thread_local_quarantine_size_kb=64','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
    jobs=[('gui-asan-bounded',['python3',str(w/'gui.py'),'--repo','/home/avo/Projects/private/dmenu-preview-next','--binary','/tmp/preview-native-0x2eGC/asan-local/dmenu','--output',str(w/'gui-asan-bounded')])]
    for kind,build in [('asan','asan-local'),('ubsan','ubsan-default')]:
        clip=w/('clip-'+kind+'-check');clip.mkdir();jobs.append(('clip-'+kind+'-check',['/tmp/preview-native-0x2eGC/'+build+'/preview-clip',str(clip)]))
    (w/'gdb-input').write_text('red\ngreen\n')
    base=['gdb','-q','-nx','-batch','-ex','set pagination off','-ex','set debuginfod enabled off']
    binary='/tmp/preview-native-0x2eGC/ubsan-default/dmenu'
    jobs.append(('gdb-no-preview',base+['-ex','break run','-ex','run < '+str(w/'gdb-input'),'-ex','print preview','-ex','kill','--args',binary]))
    helper=w/'gdb-helper';helper.write_text('#!/bin/sh\ncat >/dev/null\nhead -c 65537 /dev/zero\n');helper.chmod(0o700)
    jobs.append(('gdb-preview-bounds',base+['-ex','break dmenu.c:172','-ex','run < '+str(w/'gdb-input'),'-ex','print displaycap','-ex','print rowcap','-ex','print preview.used','-ex','print sizeof(*preview.rows)','-ex','kill','--args',binary,'-l','6','-P',str(helper)]))
    outcomes=[]
    for name,cmd in jobs:
        p=subprocess.run(cmd,env=env,capture_output=True,timeout=110);(w/(name+'.stdout')).write_bytes(p.stdout);(w/(name+'.stderr')).write_bytes(p.stderr);outcomes.append({'name':name,'command':cmd,'exit':p.returncode});print(name,'exit',p.returncode,flush=True)
    (w/'final-run.json').write_text(json.dumps({'env':{k:env[k] for k in ['DISPLAY','ASAN_OPTIONS','UBSAN_OPTIONS']},'outcomes':outcomes},indent=2))
finally:
    x.terminate();x.wait(timeout=5);log.close()
