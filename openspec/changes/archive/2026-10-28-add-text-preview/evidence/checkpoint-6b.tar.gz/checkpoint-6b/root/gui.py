#!/usr/bin/env python3
"""Focused 6B resource checks; reuses existing Menu/helper/group instrumentation."""
import argparse, importlib.util, json, os, subprocess, time
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--repo',required=True); p.add_argument('--binary',required=True); p.add_argument('--output',required=True); a=p.parse_args()
out=Path(a.output); out.mkdir(parents=True,exist_ok=False)
spec=importlib.util.spec_from_file_location('checkpoint',Path(a.repo)/'tests/preview-checkpoint.py'); h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
h.DIAGNOSTICS_DIR=out/'diagnostics'; h.REPORT_DIR=out
helper=out/'helper'; h.make_helper(helper)
env={**os.environ,'ASAN_OPTIONS':os.environ.get('ASAN_OPTIONS','detect_leaks=0'),'UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
results=[]
def wait(pred,seconds=2):
    end=time.monotonic()+seconds
    while not pred():
        assert time.monotonic()<end,'watchdog expired'
        time.sleep(.005)
def sample(m):
    proc=Path('/proc')/str(m.process.pid); fields=(proc/'stat').read_text().rsplit(')',1)[1].split()
    children=(proc/'task'/str(m.process.pid)/'children').read_text().split()
    return {'time':time.monotonic(),'rss_pages':int((proc/'statm').read_text().split()[1]),'fds':len(list((proc/'fd').iterdir())),'children':children,'zombies':[c for c in children if (Path('/proc')/c/'stat').read_text().rsplit(')',1)[1].split()[0]=='Z'],'cpu_ticks':int(fields[11])+int(fields[12]),'wchan':(proc/'wchan').read_text().strip()}
def openmenu(name,mode=None,args=None):
    e=env if mode is None else h.helper_env(env,out/(name+'.jsonl'),mode,PREVIEW_BYTES=65537)
    return h.invoke(a.binary,args or ([] if mode is None else ['-l','6','-P',str(helper)]),b'red\ngreen\nblue\n',e)
def records(name): return h.read_log(out/(name+'.jsonl'))
def finish(m,key,expected):
    start=time.monotonic(); actual=m.finish(key); elapsed=time.monotonic()-start
    assert actual[:2]==expected,(actual,expected)
    assert elapsed<.3,elapsed
    return elapsed
try:
    m=openmenu('idle')
    try:
        time.sleep(.5)  # Exclude startup/font/sanitizer initialization from idle samples.
        samples=[]
        for i in range(20): samples.append(sample(m)); time.sleep(.05)
        assert all(not s['children'] for s in samples)
        assert len({s['fds'] for s in samples})==1
        assert max(s['cpu_ticks'] for s in samples)-min(s['cpu_ticks'] for s in samples)<=2
        assert max(s['rss_pages'] for s in samples)-min(s['rss_pages'] for s in samples)<=64
        results.append({'case':'no-preview-idle','samples':samples,'exit_seconds':finish(m,'Escape',(b'',1))})
    finally: m.close()
    for mode in ['no-read','truncate','content']:
        name='churn-'+mode; m=openmenu(name,mode)
        try:
            wait(lambda:len(records(name))>=1); samples=[]; cancellations=[]
            for i in range(48):
                previous=records(name)[-1]; count=len(records(name)); start=time.monotonic()
                m.key('Down' if i%2==0 else 'Up')
                wait(lambda:len(records(name))>count)
                wait(lambda:not Path('/proc',str(previous['pid'])).exists())
                live,zombies=h.observe_group(previous['pgid'],start); assert not live
                # Finished/overflow requests must settle before measuring heap residency.
                if mode!='no-read':
                    proc=Path('/proc')/str(m.process.pid); cp=proc/'task'/str(m.process.pid)/'children'
                    wait(lambda:not cp.read_text().strip()); time.sleep(.03)
                s=sample(m); assert not s['zombies']; assert len(s['children'])<=1
                samples.append(s); cancellations.append(time.monotonic()-start)
            start=time.monotonic(); m.key('z'); proc=Path('/proc')/str(m.process.pid)
            wait(lambda:not (proc/'task'/str(m.process.pid)/'children').read_text().strip())
            live,z=h.observe_group(records(name)[-1]['pgid'],start); assert not live
            settled=sample(m); assert not settled['children']; assert settled['fds']==samples[0]['fds']-(1 if mode=='no-read' else 0)
            rss=[s['rss_pages'] for s in samples[10:]]+[settled['rss_pages']]
            maps=(proc/'maps').read_text(); budget=2048 if 'asan' in maps else 256
            (out/(name+'-samples.json')).write_text(json.dumps({'samples':samples,'settled':settled,'rss':rss},indent=2))
            assert max(rss)-min(rss)<=budget,(mode,min(rss),max(rss),budget)
            results.append({'case':name,'starts':len(records(name)),'samples':samples,'settled':settled,'post_warmup_rss_span_pages':max(rss)-min(rss),'rss_budget_pages':budget,'cancellation_seconds':cancellations,'exit_seconds':finish(m,'Escape',(b'',1))})
        finally:m.close()
    for mode,delay in [('no-read',1.12),('close-stdout',1.12),('descendant-pipe',1.12),('descendant-exit',.12),('unlimited',.12),('nonzero',.12)]:
        name='cleanup-'+mode; m=openmenu(name,mode)
        try:
            wait(lambda:bool(records(name))); origin=records(name)[0]['started_monotonic']; time.sleep(delay)
            wait(lambda:not sample(m)['children']); s=sample(m)
            live,z=h.observe_group(records(name)[0]['pgid'],origin); assert not live
            assert s['fds']==4,(mode,s)
            results.append({'case':name,'settled':s,'exit_seconds':finish(m,'Escape',(b'',1))})
        finally:m.close()
    for mode in ['descendant-pipe','no-read']:
        for key,expected in [('Escape',(b'',1)),('Return',(b'red\n',0))]:
            name='exit-'+mode+'-'+key; m=openmenu(name,mode)
            try:
                wait(lambda:bool(records(name))); time.sleep(.04); start=time.monotonic()
                elapsed=finish(m,key,expected)
                live,z=h.observe_group(records(name)[0]['pgid'],start); assert not live
                release=openmenu('released')
                try: release_elapsed=finish(release,'Return',(b'red\n',0))
                finally: release.close()
                results.append({'case':name,'menu_exit_seconds':elapsed,'group_observation_seconds':h.GROUP_OBSERVATIONS[-1]['observation_elapsed'],'group_zombies':z,'next_menu_return_seconds':release_elapsed})
            finally:m.close()
    h.check_diagnostics()
    (out/'success').write_text('PASS\n')
finally:
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    (out/'groups.json').write_text(json.dumps(h.GROUP_OBSERVATIONS,indent=2)+'\n')
    print(json.dumps({'cases':len(results),'groups':len(h.GROUP_OBSERVATIONS),'sanitizer_errors':h.DIAGNOSTIC_ERRORS,'output':str(out)}))
