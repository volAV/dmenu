#!/usr/bin/env python3
import importlib.util,os,json,subprocess,time,re
from pathlib import Path
w=Path(__file__).parent; repo=Path('/home/avo/Projects/private/dmenu-preview-next'); binary='/tmp/preview-native-0x2eGC/local/dmenu'
s=importlib.util.spec_from_file_location('h',repo/'tests/preview-checkpoint.py'); h=importlib.util.module_from_spec(s); s.loader.exec_module(h)
out=w/'trace'; out.mkdir(); h.DIAGNOSTICS_DIR=out/'diagnostics'; helper=out/'helper'; h.make_helper(helper)
wrapper=out/'traced-menu'; wrapper.write_text('#!/bin/sh\nexec /usr/bin/strace -f -ttt -e trace=kill,wait4,waitid,poll,ppoll,clone,clone3 -o "$TRACE_OUTPUT" '+binary+' "$@"\n'); wrapper.chmod(0o700)
results=[]
def groups(pgid):
    live=[]; zombies=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:f=(p/'stat').read_text().rsplit(')',1)[1].split()
        except (FileNotFoundError,ProcessLookupError):continue
        if int(f[2])==pgid:(zombies if f[0]=='Z' else live).append(int(p.name))
    return live,zombies
for mode in ['idle','exit','timeout','overflow','success']:
    log=out/(mode+'.trace'); helperlog=out/(mode+'.jsonl'); env={**os.environ,'TRACE_OUTPUT':str(log)}
    if mode!='idle':env=h.helper_env(env,helperlog,{'exit':'descendant-pipe','timeout':'descendant-pipe','overflow':'unlimited','success':'descendant-exit'}[mode])
    m=h.invoke(str(wrapper),[] if mode=='idle' else ['-l','6','-P',str(helper)],b'red\n',env)
    try:
        if mode=='idle':
            time.sleep(.2); before=log.read_text(); time.sleep(1); after=log.read_text()
            assert before==after,'idle syscalls repeated'
            origin=time.time(); actual=m.finish('Escape'); assert actual[:2]==(b'',1)
            results.append({'case':mode,'idle_trace_unchanged_seconds':1,'trace_tail':before.splitlines()[-1:]})
            continue
        end=time.monotonic()+2
        while not h.read_log(helperlog):assert time.monotonic()<end; time.sleep(.005)
        record=h.read_log(helperlog)[0]; pgid=record['pgid']
        if mode=='exit':
            time.sleep(.04); origin=time.time(); actual=m.finish('Escape'); exited=time.time(); assert actual[:2]==(b'',1)
        else:origin=None;exited=None
        deadline=time.monotonic()+2; killtime=None
        while killtime is None:
            for line in log.read_text().splitlines():
                match=re.search(r'(\d+\.\d+) kill\(-'+str(pgid)+r', SIGKILL\)',line)
                if match:killtime=float(match[1]);break
            assert time.monotonic()<deadline,'no SIGKILL dispatch found'
            if killtime is None:time.sleep(.002)
        while True:
            live,zombies=groups(pgid); observed=time.time()
            assert observed-killtime<=2,'group exceeded dispatch-anchored 2000ms'
            if not live:break
            time.sleep(.002)
        results.append({'case':mode,'pgid':pgid,'sigkill_dispatch_epoch':killtime,'observed_epoch':observed,'group_termination_observed_seconds':observed-killtime,'menu_exit_seconds':None if exited is None else exited-origin,'zombies':zombies})
        if mode!='exit':assert m.finish('Escape')[:2]==(b'',1)
    finally:m.close()
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n'); print(json.dumps(results,indent=2))
