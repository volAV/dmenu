import subprocess,os,select,importlib.util,json,time
from pathlib import Path
w=Path('/var/tmp/dmenu-checkpoint-6b/leaks-final');w.mkdir();r,fd=os.pipe();log=(w/'xvfb.stderr').open('wb');x=subprocess.Popen(['/tmp/dmenu-preview-checkpoint-RBbWFs/xvfb/usr/bin/Xvfb','-displayfd',str(fd),'-screen','0','1024x768x24','-nolisten','tcp','-noreset'],pass_fds=(fd,),stdout=subprocess.DEVNULL,stderr=log);os.close(fd)
try:
 assert select.select([r],[],[],10)[0];d=':'+os.read(r,32).decode().strip();os.close(r);os.environ['DISPLAY']=d;s=importlib.util.spec_from_file_location('h','/home/avo/Projects/private/dmenu-preview-next/tests/preview-checkpoint.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);h.DIAGNOSTICS_DIR=w/'diagnostics';helper=w/'helper';h.make_helper(helper);rows=[]
 for mode in ['no-preview','preview']:
  env={**os.environ,'ASAN_OPTIONS':'detect_leaks=1','UBSAN_OPTIONS':'halt_on_error=1'}
  if mode=='preview':env=h.helper_env(env,w/'helper.jsonl','content')
  m=h.invoke('/tmp/preview-native-0x2eGC/asan-local/dmenu',[] if mode=='no-preview' else ['-l','6','-P',str(helper)],bytes([114,101,100,10]),env)
  try:
   time.sleep(.2);result=m.finish('Return');(w/(mode+'.stderr')).write_text(result[2]);rows.append({'mode':mode,'exit':result[1],'stdout_hex':result[0].hex()});print(mode,result[1],result[2][-450:])
  finally:m.close()
 (w/'results.json').write_text(json.dumps(rows,indent=2))
finally:x.terminate();x.wait(timeout=5);log.close()