#!/usr/bin/python3
import os, sys, time
label = sys.stdin.buffer.readline().strip()
with open(os.environ["PREVIEW_LOG"], "a", encoding="ascii") as log:
    log.write(label.decode("ascii") + "\n")
if label == b"unicode":
    data = ("ASCII line\n\nLatin café; Кириллица; Ελληνικά; 中文; 😀; e\u0301\nend\n").encode()
    if os.environ.get("PREVIEW_ALT"):
        data = b"alternate rendered contents\n"
elif label == b"malformed":
    data = b"bad:\xff\ncontrols:\x00\x1b\r\x01\x7f\xc2\x80\nCRLF:\r\nnext\nlong:" + b"W" * 500
elif label == b"large":
    data = b"\t" * 16000
else:
    data = b"LATEST PREVIEW\n"
if os.environ.get("PREVIEW_LOADING_REF"):
    data = b"Loading\n"
sys.stdout.buffer.write(data)
sys.stdout.buffer.flush()
with open(os.environ["PREVIEW_LOG"], "a", encoding="ascii") as log:
    log.write("done:" + label.decode("ascii") + "\n")
